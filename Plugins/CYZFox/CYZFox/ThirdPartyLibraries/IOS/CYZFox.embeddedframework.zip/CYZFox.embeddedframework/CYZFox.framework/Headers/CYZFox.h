#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CYZFoxEvent.h"
#import "CYZFoxConfig.h"

#import <UIKit/UIKit.h>

//! Project version number for FoxCore.
FOUNDATION_EXPORT double FoxCoreVersionNumber;

//! Project version string for FoxCore.
FOUNDATION_EXPORT const unsigned char FoxCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CYZFox/PublicHeader.h>


#pragma mark - APIs definition

/**
 * Option for method "onLaunchWithOption:"
 */
@interface CYZFoxTrackOption : NSObject

/**
 * type of callback invoked after tracking finished
 */
typedef void (^CYZOnTrackFinished)();

/** @name Properties */

/**
 * should track enabled
 */
@property (nonatomic, getter = isOptout) BOOL optout;

/**
 * landing page to be redirected after tracking finished
 */
@property (nonatomic, nullable) NSString* redirectURL;

/**
 * client user identifier
 */
@property (nonatomic, nullable) NSString* buid;

/**
 * callback invoked after track is finished
 */
@property (nonatomic, copy, nullable) CYZOnTrackFinished onTrackFinished;

@end

/**
 * Main APIs
 */
@interface CYZFox : NSObject

/** @name Tracking APIs */
#pragma mark - Tracking APIs
/**
 * launch event tracking by default.
 */
+(void) trackInstall;

/**
 * launch event tracking with indicated option
 * @param option indicated option
 */
+(void) trackInstallWithOption:(nonnull CYZFoxTrackOption*) option;

/**
 * Receive the URL for re-engagement tracking.
 * Should be called within method UIApplicationDelegate -application:openUrl:sourceApplication:annotation
 * @param url URL includes customized URL scheme
 */
+(void) handleOpenURL:(nonnull NSURL*) url;

/**
 * track session
 */
+(void) trackSession;

/**
 * track event
 * @param event tracking event to be sent
 */
+(void) trackEvent:(nonnull CYZFoxEvent*) event;

/**
 * Get shared user info
 */
+(nullable NSDictionary*) getUserInfo;

/**
 * Set shared user info shared for all events
 * @param userInfo shared user info
 */
+(void) setUserInfo:(nonnull NSDictionary*) userInfo;

/**
 * Check whether install conversion has succeeded.
 */
+(BOOL) isConversionCompleted;

/**
 * Track event by external browser
 * @param redirectURL URL will be open by Safari Browser
 */
+(void) trackEventByBrowser:(nonnull NSString*) redirectURL;

@end


