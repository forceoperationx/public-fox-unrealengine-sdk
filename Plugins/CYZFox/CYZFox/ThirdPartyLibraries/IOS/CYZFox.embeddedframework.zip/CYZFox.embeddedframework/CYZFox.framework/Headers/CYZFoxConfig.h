#import <Foundation/Foundation.h>

/**
 * Configuration for SDK, should be activited before any API is invoked.
 */
@interface CYZFoxConfig : NSObject


#pragma mark - properties
#pragma mark -required
/** @name Properties required */

/**
 * application identifier from FOX
 */
@property (nonatomic, copy, readonly, nonnull) NSString* appId;

/**
 * salt for digest from FOX
 */
@property (nonatomic, copy, readonly, nullable) NSString* salt;

/**
 * application unique key from FOX
 */
@property (nonatomic, copy, readonly, nullable) NSString* appKey;


#pragma mark -optional
/** @name Properties optional */

/**
 * specified server URL for conversion tracking
 */
@property (nonatomic, copy, nullable) NSString* foxServerURL;

/**
 * specified server URL for event analytics
 */
@property (nonatomic, copy, nullable) NSString* analyticsServerURL;

/**
 * enable debug mode to show debug log
 */
@property (nonatomic, getter = isDebugMode) BOOL debugMode;

#if !TARGET_OS_TV
/**
 * enable event tracking within UIWebView
 */
@property (nonatomic, getter = isWebViewTrackingEnabled) BOOL webViewTrackingEnabled;

/**
 * enable customized User-Agent support
 */
@property (nonatomic, readonly, getter = isCustomizedUserAgentEnabled) BOOL customizedUserAgentEnabled;
#endif

#pragma mark - init API
/** @name Initialize methods */

+(nullable instancetype) new __unavailable;

/**
 * configuration with required information
 * @param appId application identifier from FOX
 * @param salt salt for digest from FOX
 * @param appKey application unique key from FOX
 */
+(nullable CYZFoxConfig*) configWithAppId:(NSUInteger) appId salt:(nonnull NSString*) salt appKey:(nonnull NSString*) appKey;

-(nullable instancetype) init __unavailable;


#pragma mark - optional API

/**
 * enable debug moe
 */
-(void) enableDebugMode;

#if !TARGET_OS_TV
/**
 * enable event tracking with UIWebView
 */
-(void) enableWebViewTracking;

/**
 * enable customized User-Agent Support
 * !must call this method before the User-Agent changing
 */
-(void) enableCustomizedUserAgent;
#endif

#pragma mark - activate

/** @name Activate configuration */

/**
 * reflect the configuration on application
 * !only effects when being invoked for first time.
 */
-(void) activate;

@end
