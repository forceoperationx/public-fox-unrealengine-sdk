#import <Foundation/Foundation.h>

/**
 * Configuration for SDK, should be activited before any API is invoked.
 */
@interface CYZFoxConfig : NSObject


#pragma mark - properties
#pragma mark -required
/** @name Properties required */

/**
 * application identifier from CYZ
 */
@property (nonatomic, readonly, nonnull) NSString* appId;

/**
 * salt for digest from CYZ
 */
@property (nonatomic, readonly, nullable) NSString* salt;

/**
 * application unique key from CYZ
 */
@property (nonatomic, readonly, nullable) NSString* appKey;


#pragma mark -optional
/** @name Properties optional */

/**
 * specified server URL for conversion tracking
 */
@property (nonatomic, nullable) NSString* foxServerURL;

/**
 * specified server URL for event analytics
 */
@property (nonatomic, nullable) NSString* analyticsServerURL;

/**
 * enable debug mode to show debug log
 */
@property (nonatomic, getter = isDebugMode) BOOL debugMode;

/**
 * enable event tracking within UIWebView
 */
@property (nonatomic, getter = isWebViewTrackingEnabled) BOOL webViewTrackingEnabled;


#pragma mark - init API
/** @name Initialize methods */

+(nullable instancetype) new __unavailable;

/**
 * configuration with required information
 * @param appId application identifier from CYZ
 * @param salt salt for digest from CYZ
 * @param appKey application unique key from CYZ
 */
+(nullable CYZFoxConfig*) configWithAppId:(NSUInteger) appId salt:(nonnull NSString*) salt appKey:(nonnull NSString*) appKey;

-(nullable instancetype) init __unavailable;


#pragma mark - optional API

/**
 * enable debug moe
 */
-(void) enableDebugMode;

/**
 * enable event tracking with UIWebView
 */
-(void) enableWebViewTracking;


#pragma mark - activate

/** @name Activate configuration */

/**
 * reflect the configuration on application
 * !only effects when being invoked for first time.
 */
-(void) activate;

@end
